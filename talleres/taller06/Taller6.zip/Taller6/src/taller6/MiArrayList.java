package taller6;

/**
 * Taller 6. MiArrayList. Aqui se implementan los dos atributos, constructor y
 * metodos de la clase MiArrayList que simula el comportamiento de un ArrayList
 *
 * @author Alejandro Cano Munera
 * @author Jorge Luis Herrera Chamat
 * @version Agosto 2017
 */
public class MiArrayList {

    /**
     * Atributos de MiArrayList
     */
    private int size;                                   //Tamaño acutal
    private static final int DEFAULT_CAPACITY = 1000;   //Tamaño por defecto
    private final int elements[];                       //Arreglo

    /**
     * Constructo de la clase MiArrayList. Inicializa los atributos size en cero
     * y elements como un arreglo de tamaño DEFAULT_CAPACITY. No, no recibe
     * parámetros.
     */
    public MiArrayList() {
        this.size = 0;
        this.elements = new int[DEFAULT_CAPACITY];
    }

    /**
     * Metodo size().
     *
     * @return se retorna el tamaño de la lista.
     */
    public int size() {
        return this.size;
    }

    /**
     * metodo add(int e). Agrega un elemento e a la última posición de la lista
     *
     * @param e Es el elemento que se va a agregar.
     */
    public void add(int e) {
        int d = this.size();
        this.elements[d] = e;
        this.size++;
    }

    /**
     * metodo get(int i).
     *
     * @param i es la posicion del elemento que se desea obtener
     * @return se retorna el elemento que se encuentra en la posición i de la
     * lista
     */
    public int get(int i) {
        return this.elements[i];
    }

    /**
     * metodo add(int index, int e). Agrega un elemento e en la posición index
     * de la lista
     *
     * @param index es la posicion donde se desea agregar el elemento
     * @param e es el elemento que se desea agregar
     */
    public void add(int index, int e) {
        int tam = this.size;
        if (index >= tam && this.elements[index] == 0) {
            this.elements[index] = e;
        } else if (index < tam && this.elements[index] != 0) {
            int t = this.elements[index];
            for (int i = index + 1; i < this.elements.length - 1; i++) {
                int o = this.elements[i];
                this.elements[i] = t;
                t = o;
            }
            this.elements[index] = e;
        }
        this.size++;
    }

    /**
     * Metodo imprimir(). Este metodo recorre e imprime los elementos de un
     * MiArrayList.
     */
    public void imprimir() {
        System.out.print("[");
        for (int i = 0; i < this.size; i++) {
            System.out.print(this.elements[i]);
            if (i != this.size - 1) {
                System.out.print(",");
            }
        }
        System.out.print("]");
        System.out.println("");
    }

}
