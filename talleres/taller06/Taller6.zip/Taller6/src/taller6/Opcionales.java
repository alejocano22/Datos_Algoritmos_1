package taller6;

import java.util.ArrayList;
import java.util.Scanner;

/**
 * Taller 6. Puntos Opcionales. Aqui se implementan los dos metodos opcionales
 * del taller 6 con ArrayList y se prueban en el metodo main.
 *
 * @author Alejandro Cano Munera
 * @author Jorge Luis Herrera Chamat
 * @version Agosto 2017
 */
public class Opcionales {

    /**
     * Metodo main. Donde se prueba el funcionamiento de los metodos
     *
     * @param args
     */
    public static void main(String[] args) {
        System.out.println(patronArray(4).toString());
        System.out.println(invertidos().toString());
    }

    /**
     * Metodo patronArray(int n). Este metodo recibe como paramatro un n y
     * realiza un patron numerico hasta dicho valor.
     *
     * @param n valor hasta el cual se repetira el patron
     * @return se retorna un arrayList con el patron.
     */
    public static ArrayList<Integer> patronArray(int n) {
        ArrayList<Integer> array = new ArrayList();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                array.add(j);
            }
        }
        return array;
    }

    /**
     * Metodo invertidos(). Este metodo pide al usuario ingresar valores
     * aleatorios enteros y devuelve un ArrayList con estos valores invertidos
     *
     * @return Se retorna un ArrayList con los valores invertidos que el usuario
     * ingreso
     */
    public static ArrayList<Integer> invertidos() {
        Scanner lect = new Scanner(System.in);
        ArrayList<Integer> array = new ArrayList();
        int numero;
        do {
            System.out.println("Digite numero: ");
            numero = lect.nextInt();
            if (numero != -1) {
                array.add(0, numero);
            }
        } while (numero != -1);
        return array;
    }

}
