package taller6;

import java.util.Scanner;

/**
 * Taller 6. Puntos Opcionales con MiArrayList. Aqui se implementan los dos
 * metodos opcionales del taller 6 con MiArrayList y se prueban en el metodo
 * main.
 *
 * @author Alejandro Cano Munera
 * @author Jorge Luis Herrera Chamat
 * @version Agosto 2017
 */
public class OpcionalesConMiArrayList {

    /**
     * Metodo main. Donde se prueba el funcionamiento de los metodos
     *
     * @param args
     */
    public static void main(String[] args) {
        patronArray(4).imprimir();
        System.out.println();
        invertidos().imprimir();
    }

    /**
     * Metodo patronArray(int n). Este metodo recibe como paramatro un n y
     * realiza un patron numerico hasta dicho valor.
     *
     * @param n valor hasta el cual se repetira el patron
     * @return se retorna un MiArrayList con el patron.
     */
    public static MiArrayList patronArray(int n) {
        MiArrayList array = new MiArrayList();
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= i; j++) {
                array.add(j);
            }
        }

        return array;
    }

    /**
     * Metodo invertidos(). Este metodo pide al usuario ingresar valores
     * aleatorios enteros y devuelve un MiArrayList con estos valores
     * invertidos.
     *
     * @return Se retorna un MiArrayList con los valores invertidos que el
     * usuario ingreso
     */
    public static MiArrayList invertidos() {
        Scanner lect = new Scanner(System.in);
        MiArrayList array = new MiArrayList();
        int numero;
        do {
            System.out.println("Digite numero: ");
            numero = lect.nextInt();
            if (numero != -1) {
                array.add(0, numero);
            }
        } while (numero != -1);
        return array;
    }
}
